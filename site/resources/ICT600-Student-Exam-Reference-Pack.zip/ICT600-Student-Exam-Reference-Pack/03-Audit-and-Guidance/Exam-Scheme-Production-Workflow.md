# ICT600 corrected examination-scheme workflow

This workflow applies to every future final examination, test, regenerated scheme and controlled correction.

## 1. Evidence intake

1. Preserve the original question and supplied official answer as read-only evidence.
2. Record the session, page count, printed marks and availability of an official answer.
3. Treat generated answers as audit targets, never as authoritative sources.
4. Use the current lecture notes for course terminology and valid solution patterns.

## 2. Question transcription

1. Capture every question and subpart exactly enough to preserve its required behaviour.
2. Record the command verb, printed marks, input data, expected output, figure dependencies and programming language.
3. Reconcile Part A, Part B and paper totals before writing answers.
4. Flag ambiguity instead of silently changing the question.

## 3. Answer construction

Every non-coding answer must contain:

- a complete model response;
- an explicit mark allocation that sums to the printed marks;
- accepted equivalent wording where relevant;
- a correction note when source material is wrong or incomplete.

Every coding answer must additionally contain:

- full runnable or complete exam-scope code, not only an approach;
- every file/page requested by the question;
- input validation and required output;
- an expected-output or behaviour statement where it aids marking;
- a feature-based marking schedule attached to the code;
- safe modern handling when historical code contains SQL injection, clear-text passwords, unsafe output or similar defects.

## 4. Presentation standard

1. Put each coding question in a blue bordered question panel.
2. Show the printed mark total visibly in the question panel.
3. Present the allocation in a bordered table with a dark header and a Total row.
4. Present code in a bordered dark-mode block with high-contrast syntax colours.
5. Use separate labelled panels for expected output and correction/marker notes.
6. Allow a long code answer to continue cleanly across pages; never shrink it until unreadable.

## 5. Technical verification

1. Check that every rubric total equals the question's printed marks.
2. Check HTML structure and required names, ids, actions and methods.
3. Syntax-check PHP and JavaScript where the environment permits.
4. Recalculate SQL conditions, string traces, totals, averages and conversion formulas independently.
5. Confirm that complete requested behaviour is present, including secondary files and error states.

## 6. Visual verification

1. Render every generated PDF page to an image.
2. Inspect all pages for clipping, overlap, blank pages and broken characters.
3. Check that dark code blocks use readable light text.
4. Check that question panels, marking tables, notes, headers, footers and page transitions remain consistent.

## 7. Packaging and publication

1. Pair each question with exactly one corrected scheme.
2. Update the coverage manifest, student guidance and checksums.
3. Rebuild the complete ZIP from the validated source folder.
4. Replace the corresponding website resources, never add an ambiguous second version.
5. Run local content tests, publish, and require a successful GitHub test and deployment workflow.

## Completion gate

A scheme is not complete when it only names an approach. It is complete only when every printed mark is traceable to an answer element and every coding question contains the complete model implementation required for a student to study and a marker to assess.
