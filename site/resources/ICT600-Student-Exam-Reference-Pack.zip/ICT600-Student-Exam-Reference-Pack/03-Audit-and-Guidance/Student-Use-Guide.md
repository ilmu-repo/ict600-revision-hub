# Student use guide

## The three-pass method

### Pass 1 - Attempt

Work from the original question paper under a realistic time limit. Mark uncertain answers with a star, but do not open the scheme yet.

### Pass 2 - Compare

Use the model answer and marking guide. For subjective questions, check whether your response contains the required ideas and explanation depth. For coding questions, compare behaviour, structure, validation and output rather than copying syntax word for word.

### Pass 3 - Repair

Rewrite only the weak answers from memory. Keep a chapter-based error list and repeat those questions after several days.

## Interpreting code answers

- A different working implementation can be fully correct.
- Minor syntax errors should not erase valid method marks.
- Historical code is corrected when it is invalid, insecure or inconsistent with the printed question.
- POST does not encrypt data; HTTPS/TLS is required for confidentiality.
- Prepared statements address SQL injection for parameter values.
- Encode untrusted output for its destination context.

## Interpreting marks

Use the printed total for the historical paper unless a correction note explicitly describes a mark conflict. A useful rule for many definition questions is one mark for the correct term/core meaning and one mark for a relevant function, distinction or explanation.
