# ICT600 Student Examination Reference Pack

This pack contains corrected, teaching-use answer schemes for every supplied past final examination and every paired Test 1 paper currently available in the course folders.

## Coverage

### Final examinations

- December 2019 - reconstructed because no official or generated answer was supplied
- January 2024
- July 2024 - now self-contained; Part B Question 2 no longer refers to another semester
- February 2025
- July 2025 - preserves and explains the printed 102-mark versus intended 100-mark conflict
- February 2026 - question-verified because no official answer was supplied
- July 2026

### Test 1

- May 2020
- Semester 20252 / May 2025
- Semester 20254 / December 2025
- Semester 20262 / May 2026

## Recommended student workflow

1. Open the matching file in the `Questions` subfolder.
2. Complete the paper without opening the corrected scheme.
3. Compare each answer with the model response and marking guide.
4. Accept equivalent technically correct wording or code, not only exact text.
5. Record weak chapters and retry those questions later.

## Important status

These are corrected student references, not replacement UiTM answer schemes. They preserve printed question totals, identify inconsistencies, correct invalid or unsafe code, and explain where official or generated material was incomplete or technically wrong.

The original Google Drive files were treated as read-only and were not modified.

## Important moderation cases

- December 2019 Question 5(c): MYR-to-USD requires division by 4.12; the printed screenshot multiplies and shows the opposite conversion.
- January 2024 PHP trace: the final search result is `bool(false)`, not `int(4)`.
- July 2024 database restrictions: a normal non-unique index does not enforce a data constraint.
- February 2025: copied names and JavaScript wording were aligned with the actual question.
- July 2025 Question 5(b): the printed paper gives 8 marks while the supplied scheme gives 6.
- February 2026: insecure generated database and form examples were replaced with validated, prepared and encoded versions.
- May 2020: invalid HTML/PHP, the wrong address variable and the unstated conversion rate are explicitly corrected.
- Semester 20254: the PHP string trace follows the printed script, not the different script used in the supplied answer.
- Semester 20262: invalid CSS comments were corrected and modern `defer` loading is accepted.
